package com.capgemini.surveysystem.beans;

import java.io.Serializable;

/**
 * 
 * This class consists of properties of respondent Setter and Getter methods of
 * properties
 */

public class RespondentBean implements Serializable {
	
	private static final long serialVersionUID = 1576331309257868477L;
	private String userName;
	private String password;
	private Long phoneNo;

	public RespondentBean() {

	}

	/**
	 * @return username
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param Username
	 */

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param Password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return phoneNo
	 */
	public Long getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo
	 */
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return String
	 */
	@Override
	public String toString() {
		return "RespondentBean [userName=" + userName + ", password=" + password + ", phoneNo=" + phoneNo + "]";
	}

}
