package com.capgemini.surveysystem.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ConcurrentModificationException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.beans.SurveyBean;
import com.capgemini.surveysystem.beans.SurveyorBean;
import com.capgemini.surveysystem.exceptions.SurveyNameFoundException;
import com.capgemini.surveysystem.exceptions.SurveyNotFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.service.SurveyorService;
import com.capgemini.surveysystem.validation.InputValidations;

/**
 * 
 * @author mukesh reddy
 *
 */
public class SurveyorController {
	static SurveyorService surveyorService = Factory.getSurveyorServiceInstance();
	static final Logger log = Logger.getLogger(SurveyorController.class);
	static InputValidations inputValidations = Factory.getInputValidationInstance();
	static SurveyBean surveybean = Factory.getSurveybeanInstance();
	SurveyorBean surveyorbean = Factory.getSurveyorbeanInstance();
	static Scanner sc = new Scanner(System.in);

	static int count = 0;

	/**
	 * This method is for surveyorlogin
	 */
	public static void surveyorLogin() {
		Properties props = new Properties();
		try {
			props.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		String UserName = props.getProperty("surveyorUsername");
		String Password = props.getProperty("surveyorPassword");

		boolean login = surveyorService.loginSurveyor(UserName, Password);
		if (login) {
			log.info(" Surveyor login successfull");
			log.info("*********************************************************");
			surveyDetails();
		} else {
			log.info("login failed");
		}
	}

	/**
	 * This method for crud operation for survey
	 * 
	 * @return true
	 */
	public static boolean surveyDetails() {
		m: do {
			log.info("select a option");
			log.info("1.add survey");
			log.info("2.update survey");
			log.info("3.delete survey");
			log.info("4.view all surveys");
			log.info("5.view responds for survey");
			log.info("6.Back");
			String choice = sc.nextLine();
			while (!surveyorService.choiceVerify(choice)) {
				log.info("please enter valid choice");
				choice = sc.nextLine();
			}
			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:
				log.info("enter survey name (a-z Ex:amazon)");
				String surveyName = sc.nextLine();
				while (!surveyorService.surveyVerify(surveyName)) {
					log.info("please enter valid survey name");
					surveyName = sc.nextLine();
				}
				try {
					surveyorService.surveyCheck(surveyName);
				} catch (SurveyNameFoundException e) {
					log.info("Survey is already present give ");
					break;
				}

				log.info("enter survey description (a-z ex: about mobile)");
				String description = sc.nextLine();
				while (!surveyorService.descriptionVerify(description)) {
					log.info("please enter valid description");
					description = sc.nextLine();
				}

				log.info("enter start date (YYYY-MM-DD)");
				String startDate = sc.nextLine();
				while (!surveyorService.dateVerify(startDate)) {
					log.info("please enter valid date");
					startDate = sc.nextLine();
				}

				LocalDate sd = LocalDate.parse(startDate);

				while (sd.isBefore(LocalDate.now())) {
					log.info("enter startdate be presentdate or futuredate");
					startDate = sc.nextLine();
					while (!surveyorService.dateVerify(startDate)) {
						log.info("please enter valid startdate");
						startDate = sc.nextLine();
					}
					try {
						sd = LocalDate.parse(startDate);
					} catch (DateTimeParseException e) {
						log.error(e.getMessage());
					}
				}

				log.info("enter end date (YYYY-MM-DD)");
				String endDate = sc.nextLine();
				while (!surveyorService.dateVerify(endDate)) {
					log.info("please enter valid date");
					endDate = sc.nextLine();
				}
				LocalDate ed = LocalDate.parse(endDate);

				while (ed.isBefore(sd)) {
					log.info("enter enddate after startdate");
					endDate = sc.nextLine();
					while (!surveyorService.dateVerify(endDate)) {
						log.info("please enter valid date");
						endDate = sc.nextLine();
					}
					try {
						ed = LocalDate.parse(endDate);
					} catch (DateTimeParseException e) {
						log.error(e.getMessage());
					}
				}
				log.info("enter question1 with one line answer(a-zA-Z Ex:what is your name?) ");
				String questionOne = sc.nextLine();
				while (!surveyorService.questionVerify(questionOne)) {
					log.info("please enter valid question");
					questionOne = sc.nextLine();
				}

				log.info("enter question2 with one line answer(a-zA-Z Ex:what is your name?)");
				String questionTwo = sc.nextLine();
				while (!surveyorService.questionVerify(questionTwo)) {
					log.info("please enter valid question");
					questionTwo = sc.nextLine();
				}

				log.info("enter question3 with discriptive answer(a-zA-Z Ex:what is your name?)");
				String questionThree = sc.nextLine();
				while (!surveyorService.questionVerify(questionThree)) {
					log.info("please enter valid question");
					questionThree = sc.nextLine();
				}

				log.info("enter question4 with discriptive answer(a-zA-Z Ex:what is your name?)");
				String questionFour = sc.nextLine();
				while (!surveyorService.questionVerify(questionFour)) {
					log.info("please enter valid question");
					questionFour = sc.nextLine();
				}

				log.info("enter question5 with multiple choice with one or more answer(a-zA-Z)");
				String questionFive = sc.nextLine();
				while (!surveyorService.questionVerify(questionFive)) {
					log.info("please enter valid question");
					questionFive = sc.nextLine();
				}

				log.info("a.option  (a-z ex:good)");

				String optionOne = sc.nextLine();
				while (!surveyorService.optionVerify(optionOne)) {
					log.info("please enter valid option");
					optionOne = sc.nextLine();
				}

				log.info("b.option  (a-z ex:good)");
				String optionTwo = sc.nextLine();
				while (!surveyorService.optionVerify(optionTwo)) {
					log.info("please enter valid option");
					optionTwo = sc.nextLine();
				}

				log.info("c.option  (a-z ex:good)");
				String optionThree = sc.nextLine();
				while (!surveyorService.optionVerify(optionThree)) {
					log.info("please enter valid option");
					optionThree = sc.nextLine();
				}

				log.info("d.option  (a-z ex:good)");
				String optionFour = sc.nextLine();
				while (!surveyorService.optionVerify(optionFour)) {
					log.info("please enter valid option");
					optionFour = sc.nextLine();
				}

				log.info("enter question6 with multiple choice with  answer(a-zA-Z)");
				String questionSix = sc.nextLine();
				while (!surveyorService.questionVerify(questionSix)) {
					log.info("please enter valid question");
					questionSix = sc.nextLine();
				}

				log.info("a.option (a-z ex:good)");
				String optionFive = sc.nextLine();
				while (!surveyorService.optionVerify(optionFive)) {
					log.info("please enter valid option");
					optionFive = sc.nextLine();
				}

				log.info("b.option (a-z ex:good) ");
				String optionSix = sc.nextLine();
				while (!surveyorService.optionVerify(optionSix)) {
					log.info("please enter valid option");
					optionSix = sc.nextLine();
				}
				log.info("c.option (a-z ex:good) ");
				String optionSeven = sc.nextLine();
				while (!surveyorService.optionVerify(optionSeven)) {
					log.info("please enter valid option");
					optionSeven = sc.nextLine();
				}

				log.info("d.option (a-z ex:good)");
				String optionEight = sc.nextLine();
				while (!surveyorService.optionVerify(optionEight)) {
					log.info("please enter valid option");
					optionEight = sc.nextLine();
				}

				log.info("enter respondent name to distribute(mukesh,reddy,bomma)");
				String distribute = sc.nextLine();
				while (!surveyorService.nameVerify(distribute)) {
					log.info("please enter valid distribute name");
					distribute = sc.nextLine();
				}
				for (SurveyBean surveybean : SurveyRepository.surveylist) {
					while (surveybean.getDistribute().contentEquals(distribute)) {
						log.info("This respodent already has a survey distributed");
						log.info("Please enter new Respondent name");
						distribute = sc.nextLine();

					}
				}

				boolean addsurvey = surveyorService.createSurvey(surveyName, description, sd, ed, questionOne,
						questionTwo, questionThree, questionFour, questionFive, optionOne, optionTwo, optionThree,
						optionFour, questionSix, optionFive, optionSix, optionSeven, optionEight, distribute);
				if (addsurvey) {
					log.info(" Survey added");
					log.info("*********************************************************");
				} else {
					log.info("Survey not added");
				}
				break;

			case 2:
				log.info("enter survey name (a-z Ex:amazon)");
				String survey1 = sc.nextLine();
				while (!surveyorService.surveyVerify(survey1)) {
					log.info("please enter valid survey name");
					survey1 = sc.nextLine();
				}
				try {
					boolean update = surveyorService.updateSurvey(survey1);
					if (update) {
						log.info("survey found");
					} else {
						log.info("survey not found");
					}
				} catch (SurveyNotFoundException e) {
					log.error(e.getMessage());
					break;
				}

				for (SurveyBean surveybean : SurveyRepository.surveylist) {
					if (surveybean.getSurveyName().contentEquals(survey1)) {
						count++;
						log.info("enter new survey name (a-z Ex:flipkart)");
						String survey2 = sc.nextLine();
						while (!surveyorService.surveyVerify(survey2)) {
							log.info("please enter valid survey name");
							survey2 = sc.nextLine();
						}
						log.info("enter new survey description (a-z Ex:mobile)");
						String description1 = sc.nextLine();
						while (!surveyorService.descriptionVerify(description1)) {
							log.info("please enter valid description");
							description1 = sc.nextLine();
						}
						log.info("enter start date (YYYY-MM-DD)");
						String startDate1 = sc.nextLine();
						while (!surveyorService.dateVerify(startDate1)) {
							log.info("please enter valid date");
							startDate1 = sc.nextLine();
						}
						LocalDate sd1 = LocalDate.parse(startDate1);

						while (sd1.isBefore(LocalDate.now())) {
							log.info("Start date be present or future");
							startDate1 = sc.nextLine();
							while (!surveyorService.dateVerify(startDate1)) {
								log.info("please enter valid startdate");
								startDate1 = sc.nextLine();
							}
							try {
								sd1 = LocalDate.parse(startDate1);
							} catch (DateTimeParseException e) {
								log.error(e.getMessage());
							}
						}

						log.info("enter new end date (YYYY-MM-DD)");
						String endDate1 = sc.nextLine();
						while (!surveyorService.dateVerify(endDate1)) {
							log.info("please enter valid date");
							endDate1 = sc.nextLine();
						}
						LocalDate ed1 = LocalDate.parse(endDate1);
						while (ed1.isBefore(sd1)) {
							log.info("end date after start date");
							endDate1 = sc.nextLine();
							while (!surveyorService.dateVerify(endDate1)) {
								log.info("please enter valid date");
								endDate1 = sc.nextLine();
							}
							try {
								ed1 = LocalDate.parse(endDate1);
							} catch (DateTimeParseException e) {
								log.error(e.getMessage());
							}
						}
						log.info("enter question1 with one line answer(a-zA-Z Ex: what is your name?) ");
						String question1 = sc.nextLine();
						while (!surveyorService.questionVerify(question1)) {
							log.info("please enter valid question");
							question1 = sc.nextLine();
						}

						log.info("enter question2 with one line answer(a-zA-Z Ex: what is your name?)");
						String question2 = sc.nextLine();
						while (!surveyorService.questionVerify(question2)) {
							log.info("please enter valid question");
							question2 = sc.nextLine();
						}

						log.info("enter question3 with discriptive answer(a-zA-Z Ex: what is your name?)");
						String question3 = sc.nextLine();
						while (!surveyorService.questionVerify(question3)) {
							log.info("please enter valid question");
							question3 = sc.nextLine();
						}

						log.info("enter question4 with discriptive answer(a-zA-Z Ex: what is your name?)");
						String question4 = sc.nextLine();
						while (!surveyorService.questionVerify(question4)) {
							log.info("please enter valid question");
							question4 = sc.nextLine();
						}
						boolean updatesurvey = surveyorService.surveyUpdate(survey1, survey2, description1, sd1, ed1,
								question1, question2, question3, question4);
						if (updatesurvey) {
							log.info("survey updated");
							log.info("*********************************************************");
						} else {
							log.info("survey not updated");
						}
					}
				}
				break;
			case 3:
				log.info("enter survey name (a-z)");
				String survey3 = sc.nextLine();
				while (!surveyorService.surveyVerify(survey3)) {
					log.info("please enter valid survey name");
					survey3 = sc.nextLine();
				}
				try {
					boolean delete = surveyorService.checkSurvey(survey3);
					if (delete) {
						log.info("survey found and deleted");
					} else {
						log.info("survey not found");
					}
				} catch (SurveyNotFoundException e) {
					log.error(e.getMessage());
				} catch (ConcurrentModificationException e) {
					log.error(e.getMessage());
				}

				break;
			case 4:
				log.info("Your surveys are:");
				boolean viewsurvey = surveyorService.surveyView();
				for (SurveyBean surveybean : SurveyRepository.surveylist) {
					if (viewsurvey) {
						log.info("survey is empty");
					}
					log.info(surveybean);
				}
				break;
			case 5:
				RespondentController.respondView();
				break;
			case 6:
				break m;
			default:
				log.info("Select valid choice");
				break;
			}
		} while (true);
		return false;
	}
}