package com.capgemini.surveysystem.service;

import com.capgemini.surveysystem.beans.ResultBean;
import com.capgemini.surveysystem.dao.RespondentDAO;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.validation.InputValidations;

public class RespondentServiceImpl implements RespondentService {
	InputValidations inputValidations = Factory.getInputValidationInstance();
	RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
	ResultBean resultbean = Factory.getResultbeanInstance();

	/**
	 * Method is for username validation
	 * 
	 * @param username
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean usernameVerify(String username) {
		return inputValidations.nameValidation(username) == true;
	}

	/**
	 * Method is for password validation
	 * 
	 * @param password
	 * @return true when matches
	 * @return false when not matches
	 */

	@Override
	public boolean passwordVerify(String password) {
		return inputValidations.passwordValidation(password) == true;

	}

	/**
	 * Method is for survey validation
	 * 
	 * @param survey
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean surveyVerify(String survey) {
		return inputValidations.surveyValidation(survey) == true;
	}

	/**
	 * Method is for multipleanswwer validation
	 * 
	 * @param answer
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean multipleanswerVerify(String answer) {
		return inputValidations.multipleanswerValidation(answer) == true;
	}

	/**
	 * Method is for answer validation
	 * 
	 * @param answer
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean answerVerify(String answer) {
		return inputValidations.answerValidation(answer) == true;
	}

	/**
	 * Method is answer choice validation
	 * 
	 * @param answer
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean answerVerify1(String answer) {
		return inputValidations.answerValidation1(answer) == true;
	}

	/**
	 * Method is for phoneNo validation
	 * 
	 * @param phonenum
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean phoneNoVerify(String phonenum) {
		return inputValidations.mobileNoValidation(phonenum) == true;

	}

	/**
	 * Method is for choice validation
	 * 
	 * @param choice
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean choiceVerify(String choice) {
		return inputValidations.choiceValidation(choice) == true;

	}

	/**
	 * Method is for adding answers
	 * 
	 * @return true when answers are added
	 * @return false when answers not added
	 */
	@Override
	public boolean addAnswers(String survey, String answerOne, String answerTwo, String answerThree, String answerFour,
			String answerFive, String answerSix) {
		return respondentDao.addAnswers(survey, answerOne, answerTwo, answerThree, answerFour, answerFive, answerSix)==true;
	}

	/**
	 * Method is for viewrespons
	 */
	@Override
	public boolean viewResponse() {

		return respondentDao.responseView();
	}

}
