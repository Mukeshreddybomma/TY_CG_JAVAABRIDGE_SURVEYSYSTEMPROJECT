package com.capgemini.surveysystem.dao;

import java.time.LocalDate;
import java.util.ConcurrentModificationException;

import com.capgemini.surveysystem.beans.SurveyBean;
import com.capgemini.surveysystem.exceptions.SurveyNotFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;

public class SurveyorDAOImpl implements SurveyorDAO {
	SurveyBean surveybean = Factory.getSurveybeanInstance();
	int count = 0;

	/**
	 * This method for surveyor login
	 * 
	 * @param UserName and Password
	 * @return true,when login true
	 */
	@Override
	public boolean surveyorLogin(String UserName, String Password) {
		return UserName.contentEquals("mukeshreddy") && Password.equals("Mukesh@13") == true;
	}

	/**
	 * this method is for update the survey
	 * 
	 * @param survey
	 * @return true,surveyfound
	 * @return false,survey not found
	 */
	@Override
	public boolean updateSurvey(String survey) throws SurveyNotFoundException, ConcurrentModificationException {
		try {
			for (SurveyBean surveybean : SurveyRepository.surveylist) {
				if (surveybean.getSurveyName().equals(survey)) {
					count++;

					return true;
				}
			}
			if (count == 0)
				throw new SurveyNotFoundException();
		} catch (ConcurrentModificationException e) {
			throw new ConcurrentModificationException();
		}
		return false;
	}

	/**
	 * this method is for delete the survey
	 * 
	 * @param survey
	 * @return true,surveyfound
	 * @return false,survey not found
	 */
	@Override
	public boolean deleteSurvey(String survey) throws SurveyNotFoundException, ConcurrentModificationException {
		try {
			for (SurveyBean surveybean : SurveyRepository.surveylist) {
				if (surveybean.getSurveyName().equals(survey)) {
					count++;
					SurveyRepository.surveylist.remove(surveybean);
					return true;
				}
			}
			if (count == 0)
				throw new SurveyNotFoundException();
		} catch (ConcurrentModificationException e) {
			throw new ConcurrentModificationException();
		}
		return false;

	}

	/**
	 * this method is for view the survey
	 */
	@Override
	public boolean viewSurvey() {
		return SurveyRepository.surveylist.isEmpty() == true;
	}

	@Override
	public boolean nameCheck(String surveyName) {
		int count = 0;
		for (SurveyBean surveybean : SurveyRepository.surveylist) {
			if (surveybean.getSurveyName().contentEquals(surveyName)) {
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	@Override
	public boolean addSurvey(String survey, String description, LocalDate sd, LocalDate ed, String questionOne,
			String questionTwo, String questionThree, String questionFour, String questionFive, String optionOne,
			String optionTwo, String optionThree, String optionFour, String questionSix, String optionFive,
			String optionSix, String optionSeven, String optionEight, String distribute) {
		surveybean.setSurveyName(survey);
		surveybean.setDescription(description);
		surveybean.setStartDate(sd);
		surveybean.setEndDate(ed);
		surveybean.setQuestionOne(questionOne);
		surveybean.setQuestionTwo(questionTwo);
		surveybean.setQuestionThree(questionThree);
		surveybean.setQuestionFour(questionFour);
		surveybean.setQuestionFive(questionFive);
		surveybean.setOptionOne(optionOne);
		surveybean.setOptionTwo(optionTwo);
		surveybean.setOptionThree(optionThree);
		surveybean.setOptionFour(optionFour);
		surveybean.setQuestionSix(questionSix);
		surveybean.setOptionFive(optionFive);
		surveybean.setOptionSix(optionSix);
		surveybean.setOptionSeven(optionSeven);
		surveybean.setOptionEight(optionEight);
		surveybean.setDistribute(distribute);
		SurveyRepository.surveylist.add(surveybean);
		return true;
	}

	public boolean surveyUpdate(String survey1, String survey2, String description1, LocalDate sd1, LocalDate ed1,
			String question1, String question2, String question3, String question4) {
		for (SurveyBean surveybean : SurveyRepository.surveylist) {
			if (surveybean.getSurveyName().contentEquals(survey1)) {
				surveybean.setSurveyName(survey2);
				surveybean.setDescription(description1);
				surveybean.setStartDate(sd1);
				surveybean.setEndDate(ed1);
				surveybean.setQuestionOne(question1);
				surveybean.setQuestionTwo(question2);
				surveybean.setQuestionThree(question3);
				surveybean.setQuestionFour(question4);
				return true;
			}
		}
		return false;
	}
}