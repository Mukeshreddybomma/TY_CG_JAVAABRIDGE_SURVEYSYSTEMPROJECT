package com.capgemini.surveysystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveysystem.beans.RespondentBean;
import com.capgemini.surveysystem.factory.Factory;

public class RespondentRepository {
	public static ArrayList<RespondentBean> respondentlist = new ArrayList<RespondentBean>();

	/**
	 * This method is for dummy data of respondent
	 * 
	 * @return true, respondent added
	 */
	public List<RespondentBean> respondent() {
		RespondentBean respondentbean1 = Factory.getRespondentbeanInstance();
		respondentbean1.setUserName("mukeshreddy");
		respondentbean1.setPassword("Mukesh@13");
		respondentbean1.setPhoneNo(8096741045l);
		respondentlist.add(respondentbean1);
		RespondentBean respondentbean2 = Factory.getRespondentbeanInstance();
		respondentbean2.setUserName("mukeshbomma");
		respondentbean2.setPassword("Mukesh@13");
		respondentbean2.setPhoneNo(8096741045l);
		respondentlist.add(respondentbean2);
		RespondentBean respondentbean3 = Factory.getRespondentbeanInstance();
		respondentbean3.setUserName("mukesh");
		respondentbean3.setPassword("Mukesh@13");
		respondentbean3.setPhoneNo(8096741045l);
		respondentlist.add(respondentbean3);
		RespondentBean respondentbean4 = Factory.getRespondentbeanInstance();
		respondentbean4.setUserName("bomma");
		respondentbean4.setPassword("Mukesh@13");
		respondentbean4.setPhoneNo(8096741045l);
		respondentlist.add(respondentbean4);
		RespondentBean respondentbean5 = Factory.getRespondentbeanInstance();
		respondentbean5.setUserName("capgemini");
		respondentbean5.setPassword("Mukesh@13");
		respondentbean5.setPhoneNo(8096741045l);
		respondentlist.add(respondentbean5);
		RespondentBean respondentbean6 = Factory.getRespondentbeanInstance();
		respondentbean6.setUserName("reddy");
		respondentbean6.setPassword("Mukesh@13");
		respondentbean6.setPhoneNo(8096741045l);
		respondentlist.add(respondentbean6);

		return respondentlist;

	}
}