package com.capgemini.surveysystem.service;

public interface AdminService {

	public boolean loginAdmin(String UserName, String Password);

	public boolean choiceVerify(String choice);

	public boolean usernameVerify(String username);

	public boolean passwordVerify(String password);

	public boolean respondentRegistration(String userName, Long mobileNo, String password);

	public boolean mobileNoVerify(String phoneNo);
	
	public boolean userCheck(String userName);

}
