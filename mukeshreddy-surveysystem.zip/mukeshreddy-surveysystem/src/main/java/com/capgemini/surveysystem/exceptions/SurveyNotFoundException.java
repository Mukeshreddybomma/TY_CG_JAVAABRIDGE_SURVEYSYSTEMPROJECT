package com.capgemini.surveysystem.exceptions;

/**
 * @param message is the argument for SurveyNotFoundException
 * @exception SurveyNotFoundException it is custom exceptions it extends
 *                                    RunetimeException
 * @throws message Survey is not found
 */
public class SurveyNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 5926395443364272625L;
	String message = "Survey  not found";

	public SurveyNotFoundException() {

	}

	public SurveyNotFoundException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
