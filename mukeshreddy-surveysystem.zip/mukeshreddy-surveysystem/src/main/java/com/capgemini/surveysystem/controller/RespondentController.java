package com.capgemini.surveysystem.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.beans.RespondentBean;
import com.capgemini.surveysystem.beans.ResultBean;
import com.capgemini.surveysystem.beans.SurveyBean;
import com.capgemini.surveysystem.dao.RespondentDAOImpl;
import com.capgemini.surveysystem.exceptions.InvalidRespondentException;
import com.capgemini.surveysystem.exceptions.InvalidSurveynameException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.service.RespondentService;
import com.capgemini.surveysystem.validation.InputValidations;

/**
 * 
 * @author mukesh reddy
 *
 */
public class RespondentController {
	static final Logger log = Logger.getLogger(RespondentController.class);
	static InputValidations inputValidations = Factory.getInputValidationInstance();
	static RespondentBean respondentbean = Factory.getRespondentbeanInstance();
	static RespondentService respondentService = Factory.getRespondentServiceInstance();
	static SurveyBean surveybean = Factory.getSurveybeanInstance();
	static ResultBean resultbean = Factory.getResultbeanInstance();

	static Scanner sc = new Scanner(System.in);
	/**
	 * method is for login respondent And give answers to questions
	 */
	public static void respondentLogin() {
		int count = 0;
		int count1=0;
		log.info("list of respondents are present");
		for (RespondentBean respondentbean : RespondentRepository.respondentlist) {
			log.info(respondentbean.getUserName());
		}
		log.info("enter respondent username(a-z Ex: mukesh)");
		String userName = sc.nextLine();
		while (!respondentService.usernameVerify(userName)) {
			log.info("please enter valid username ");
			userName = sc.nextLine();
		}
		log.info("enter your password (a to z A to Z 0 to 9 @!#$%  Ex: Mukesh@13)");
		String password = sc.nextLine();
		while (!respondentService.passwordVerify(password)) {
			log.info("please enter valid password");
			password = sc.nextLine();
		}
		try {
			Iterator<RespondentBean> respondentBean = RespondentRepository.respondentlist.iterator();
			while (respondentBean.hasNext()) {
				RespondentBean repondent = respondentBean.next();
				if (repondent.getUserName().contentEquals(userName)
						&& repondent.getPassword().contentEquals(password)) {
					count++;
				}
			}
			if (count == 0) {
				throw new InvalidRespondentException();
			} else {
				log.info("Respondent login success");
				log.info("*********************************************************");
				for (RespondentBean respondentbean : RespondentRepository.respondentlist) {
					if (respondentbean.getUserName().contentEquals(userName)) {
						for (SurveyBean surveybean : SurveyRepository.surveylist) {
							if (surveybean.getDistribute().contentEquals(userName)) {
								count1++;
								log.info("surveyname=" + surveybean.getSurveyName());
								String survey = surveybean.getSurveyName();

								log.info(surveybean.getQuestionOne());

								log.info(" enter answer for question1 (a-zA-Z) it includes sentences)");

								String answerOne = sc.nextLine();
								while (!respondentService.answerVerify(answerOne)) {
									log.info("please enter valid answer1");
									answerOne = sc.nextLine();
								}
								log.info(surveybean.getQuestionTwo());
								log.info(" enter answer for question 2(a-zA-Z)it includes sentences)");
								String answerTwo = sc.nextLine();
								while (!respondentService.answerVerify(answerTwo)) {
									log.info("please enter valid answer");
									answerTwo = sc.nextLine();
								}
								log.info(surveybean.getQuestionThree());

								log.info(" enter answer for question 3(a-zA-Z)it includes sentences)");
								String answerThree = sc.nextLine();
								while (!respondentService.answerVerify1(answerThree)) {
									log.info("please enter valid answer");
									answerThree = sc.nextLine();
								}

								log.info(surveybean.getQuestionFour());
								log.info(" enter answer for question 4(a-zA-Z)it includes sentences)");
								String answerFour = sc.nextLine();
								while (!respondentService.answerVerify1(answerFour)) {
									log.info("please enter valid answer");
									answerFour = sc.nextLine();
								}

								log.info(surveybean.getQuestionFour());

								log.info("select option");
								log.info("a." + surveybean.getOptionOne());
								log.info("b." + surveybean.getOptionTwo());
								log.info("c." + surveybean.getOptionThree());
								log.info("d." + surveybean.getOptionFour());

								log.info("enter answer for question5 (a-d) Ex:a");
								String answerFive = sc.nextLine();

								while (!respondentService.multipleanswerVerify(answerFive)) {
									log.info("please enter valid answer");
									answerFive = sc.nextLine();
								}

								log.info(surveybean.getQuestionSix());

								log.info("select option");
								log.info("a." + surveybean.getOptionFive());
								log.info("b." + surveybean.getOptionSix());
								log.info("c." + surveybean.getOptionSeven());
								log.info("d." + surveybean.getOptionEight());

								log.info("enter answer for question6(a-d) Ex:d");
								String answerSix = sc.nextLine();
								while (!respondentService.multipleanswerVerify(answerSix)) {
									log.info("please enter valid answer");
									answerSix = sc.nextLine();
								}

								boolean answers = respondentService.addAnswers(survey, answerOne, answerTwo, answerThree,
										answerFour, answerFive, answerSix);
								if (answers) {
									log.info(" response added");
								} else {
									log.info("Response not added");
								}

								log.info("thanks for response");

								m:do {
									log.info("************************************");
									log.info("select a option(1-2)");
									log.info("1.View response for survey");
									log.info("2.back to surveyor");
									log.info("3.back");

									String choice = sc.nextLine();
									while (!respondentService.choiceVerify(choice)) {
										log.info("please enter valid choice");
										choice = sc.nextLine();
									}
									int choice1 = Integer.parseInt(choice);

									switch (choice1) {

									case 1:
										respondView();
										break;

									case 2:
										SurveyorController.surveyorLogin();
										break;
									case 3:
										break m;
									default:
										log.info("Select valid choice");
										break;
									}

								} while (true);
							}

						}

					}
				}try {
					if (count1 == 0) {
						throw new InvalidSurveynameException();
					}
				} catch (InvalidSurveynameException e) {
					log.error(e.getMessage());
				}
			}
		} catch (InvalidRespondentException e) {
			log.error(e.getMessage());
		}
	}   
	/**
	 * This method is for viewing the response
	 * 
	 * @return respondentsurvey
	 */
	public static List<ResultBean> respondView() {
		log.info("responses for survey are:");
		boolean viewanswers = respondentService.viewResponse();
		for (ResultBean resultbean : RespondentDAOImpl.respondentsurvey) {
			if (viewanswers) {
				log.info("no response to view");
			} else {
				log.info(resultbean);
			}
		}
		return RespondentDAOImpl.respondentsurvey;
	}
}