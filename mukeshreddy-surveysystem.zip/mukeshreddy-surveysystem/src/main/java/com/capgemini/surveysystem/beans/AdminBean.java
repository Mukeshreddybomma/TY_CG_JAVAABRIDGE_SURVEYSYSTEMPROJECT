package com.capgemini.surveysystem.beans;

import java.io.Serializable;

/**
 * 
 * This class consists of properties of admin Setter and Getter methods of
 * properties
 */
public class AdminBean implements Serializable {
	
	private static final long serialVersionUID = 5791922047440329668L;
	private String userName;
	private String password;

	public AdminBean() {

	}

	/**
	 * @return userName
	 */

	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 */

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param Password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return String
	 */
	@Override
	public String toString() {
		return "AdminBean [userName=" + userName + ", password=" + password + "]";
	}

}
