package com.capgemini.surveysystem.service;

import java.time.LocalDate;

import com.capgemini.surveysystem.beans.SurveyBean;
import com.capgemini.surveysystem.dao.SurveyorDAO;
import com.capgemini.surveysystem.exceptions.SurveyNameFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.validation.InputValidations;

public class SurveryorServiceImpl implements SurveyorService {
	InputValidations inputValidations = Factory.getInputValidationInstance();
	SurveyBean surveybean = Factory.getSurveybeanInstance();
	SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();

	/**
	 * Method is for choice validation
	 * 
	 * @param choice
	 * @return true when matches
	 */
	@Override
	public boolean choiceVerify(String choice) {
		return inputValidations.choiceValidation(choice) == true;
	}

	/**
	 * Method is for description validation
	 * 
	 * @param description
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean descriptionVerify(String description) {
		return inputValidations.descriptionValidation(description) == true;
	}

	/**
	 * Method is for question validation
	 * 
	 * @param question
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean questionVerify(String question) {
		return inputValidations.questionValidation(question) == true;
	}

	/**
	 * Method is for survey validation
	 * 
	 * @param survey
	 * @return true when matches
	 * @return false when not matches
	 */

	@Override
	public boolean surveyVerify(String survey) {
		return inputValidations.surveyValidation(survey) == true;
	}

	/**
	 * Method is for date validation
	 * 
	 * @param date
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean dateVerify(String date) {
		return inputValidations.dateValidation(date) == true;
	}

	/**
	 * Method is for name validation
	 * 
	 * @param name
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean nameVerify(String name) {
		return inputValidations.nameValidation(name) == true;
	}

	/**
	 * Method is for login surveyor
	 * 
	 * @param UserName,Password
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean loginSurveyor(String UserName, String Password) {
		return surveyorDao.surveyorLogin(UserName, Password) == true;

	}

	/**
	 * Method is for checksurvey
	 * 
	 * @param survey1
	 * @return true when matches
	 * @return false when not matchses
	 */
	@Override
	public boolean checkSurvey(String survey1) {
		return surveyorDao.deleteSurvey(survey1) == true;

	}

	/**
	 * Method is for updatesurvey
	 * 
	 * @param survey
	 */
	@Override
	public boolean updateSurvey(String survey) {
		return surveyorDao.updateSurvey(survey) == true;
	}

	/**
	 * Method is for createSurvey
	 * 
	 * @return true surveyadded
	 */
	@Override
	public boolean createSurvey(String survey, String description, LocalDate sd, LocalDate ed, String questionOne,
			String questionTwo, String questionThree, String questionFour, String questionFive, String optionOne,
			String optionTwo, String optionThree, String optionFour, String questionSix, String optionFive,
			String optionSix, String optionSeven, String optionEight, String distribute) {

		return surveyorDao.addSurvey(survey, description, sd, ed, questionOne, questionTwo, questionThree, questionFour,
				questionFive, optionOne, optionTwo, optionThree, optionFour, questionSix, optionFive, optionSix,
				optionSeven, optionEight, distribute) == true;
	}

	/**
	 * Method is for surveyview
	 */
	@Override
	public boolean surveyView() {
		return surveyorDao.viewSurvey();
	}

	/**
	 * Method is for option validation
	 * 
	 * @param option
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean optionVerify(String option) {
		return inputValidations.optionValidation(option) == true;
	}

	@Override
	public boolean surveyCheck(String surveyName) {
		boolean surveyname = surveyorDao.nameCheck(surveyName);
		if (surveyname == false) {
			return true;
		} else {
			throw new SurveyNameFoundException();
		}
	}

	@Override
	public boolean surveyUpdate(String survey1, String survey2, String description1, LocalDate sd1, LocalDate ed1,
			String question1, String question2, String question3, String question4) {
		return surveyorDao.surveyUpdate(survey1, survey2, description1, sd1, ed1, question1, question2, question3,
				question4) == true;
	}

}
