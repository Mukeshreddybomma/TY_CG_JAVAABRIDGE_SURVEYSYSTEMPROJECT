package com.capgemini.surveysystem.service;

import com.capgemini.surveysystem.beans.RespondentBean;
import com.capgemini.surveysystem.dao.AdminDAO;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.validation.InputValidations;

public class AdminServiceImpl implements AdminService {
	AdminDAO adminDao = Factory.getAdminDAOInstance();
	InputValidations inputValidations = Factory.getInputValidationInstance();
	RespondentBean respondentbean = Factory.getRespondentbeanInstance();

	/**
	 * method is for adminlogin
	 * 
	 * @param UserName and Password
	 */
	@Override
	public boolean loginAdmin(String UserName, String Password) {
		return adminDao.adminLogin(UserName, Password);

	}

	/**
	 * Method is for choice validation
	 * 
	 * @param choice return true when matches return false when not matches
	 */
	@Override
	public boolean choiceVerify(String choice) {
		return inputValidations.choiceValidation(choice) == true;
	}

	/**
	 * Method is for username validation
	 * 
	 * @param username
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean usernameVerify(String username) {
		return inputValidations.nameValidation(username) == true;
	}

	/**
	 * Method is for password validation
	 * 
	 * @param password
	 * @return true when matches
	 * @return false when not matches
	 */

	@Override
	public boolean passwordVerify(String password) {
		return inputValidations.passwordValidation(password) == true;

	}

	@Override
	public boolean respondentRegistration(String userName, Long mobileNo, String password) {
		return adminDao.respondentRegistration(userName, mobileNo, password) == true;
	}

	@Override
	public boolean mobileNoVerify(String phoneNo) {
		return inputValidations.mobileNoValidation(phoneNo) == true;
	}

	@Override
	public boolean userCheck(String userName) {
		int count = 0;
		for (RespondentBean respondentBean : RespondentRepository.respondentlist) {
			if (respondentBean.getUserName().equals(userName)) {
				count++;
			}
		}
		return count == 0 ? false : true;
	}

}
