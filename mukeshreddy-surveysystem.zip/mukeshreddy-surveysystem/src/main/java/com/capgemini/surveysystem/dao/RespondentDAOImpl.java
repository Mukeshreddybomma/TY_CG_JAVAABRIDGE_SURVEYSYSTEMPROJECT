package com.capgemini.surveysystem.dao;

import java.util.ArrayList;

import com.capgemini.surveysystem.beans.ResultBean;
import com.capgemini.surveysystem.factory.Factory;

public class RespondentDAOImpl implements RespondentDAO {
	public static ArrayList<ResultBean> respondentsurvey = new ArrayList<ResultBean>();
	ResultBean resultbean = Factory.getResultbeanInstance();
	/**
	 * this method responseview id for view the results responseview
	 * 
	 * @return true
	 */
	@Override
	public boolean responseView() {
		return respondentsurvey.isEmpty() == true;

	}
	@Override
	public boolean addAnswers(String survey, String answerOne, String answerTwo, String answerThree, String answerFour,
			String answerFive, String answerSix) {
		resultbean.setSurvey(survey);
		resultbean.setAnswerOne(answerOne);
		resultbean.setAnswerTwo(answerTwo);
		resultbean.setAnswerThree(answerThree);
		resultbean.setAnswerFour(answerFour);
		resultbean.setAnswerFive(answerFour);
		resultbean.setAnswerSix(answerSix);
		respondentsurvey.add(resultbean);
		return true;
	}
}
