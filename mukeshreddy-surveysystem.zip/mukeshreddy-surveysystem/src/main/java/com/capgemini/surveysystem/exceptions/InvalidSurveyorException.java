package com.capgemini.surveysystem.exceptions;

/**
 * @param message is the argument for InvalidSurveyorException
 * @exception InvalidSurveyorException it is custom exceptions it extends
 *                                     RunetimeException
 * @throws message Surveryor is not found
 */
public class InvalidSurveyorException extends RuntimeException {

	private static final long serialVersionUID = -5203389714102967970L;
	String message = "Surveryor  not found";

	public InvalidSurveyorException() {

	}

	public InvalidSurveyorException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
