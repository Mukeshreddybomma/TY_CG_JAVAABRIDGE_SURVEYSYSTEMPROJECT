package com.capgemini.surveysystem.dao;

import java.time.LocalDate;

public interface SurveyorDAO {

	public boolean deleteSurvey(String survey);

	public boolean updateSurvey(String survey);

	public boolean surveyorLogin(String UserName, String Password);

	public boolean viewSurvey();

	public boolean nameCheck(String surveyName);

	public boolean addSurvey(String survey, String description, LocalDate sd, LocalDate ed, String questionOne,
			String questionTwo, String questionThree, String questionFour, String questionFive, String optionOne,
			String optionTwo, String optionThree, String optionFour, String questionSix, String optionFive,
			String optionSix, String optionSeven, String optionEight, String distribute);

	public boolean surveyUpdate(String survey1, String survey2, String description1, LocalDate sd1, LocalDate ed1,
			String question1, String question2, String question3, String question4);

	

}
