package com.capgemini.surveysystem.beans;

import java.io.Serializable;

/**
 * 
 * This class consists of properties of Result Setter and Getter methods of
 * properties
 */
public class ResultBean implements Serializable {

	private static final long serialVersionUID = -339593845296060465L;
	private String survey;
	private String answerOne;
	private String answerTwo;
	private String answerThree;
	private String answerFour;
	private String answerFive;
	private String answerSix;

	public ResultBean() {

	}

	/**
	 * @return survey
	 */
	public String getSurvey() {
		return survey;
	}

	/**
	 * @param survey
	 */

	public void setSurvey(String survey) {
		this.survey = survey;
	}

	/**
	 * @return answerOne
	 */
	public String getAnswerOne() {
		return answerOne;
	}

	/**
	 * @param answerOne
	 */

	public void setAnswerOne(String answerOne) {
		this.answerOne = answerOne;
	}

	/**
	 * @return answerTwo
	 */
	public String getAnswerTwo() {
		return answerTwo;
	}

	/**
	 * @param answerTwo
	 */

	public void setAnswerTwo(String answerTwo) {
		this.answerTwo = answerTwo;
	}

	/**
	 * @return answerThree
	 */
	public String getAnswerThree() {
		return answerThree;
	}

	/**
	 * @param answerThree
	 */

	public void setAnswerThree(String answerThree) {
		this.answerThree = answerThree;
	}

	/**
	 * @return answerFour
	 */
	public String getAnswerFour() {
		return answerFour;
	}

	/**
	 * @param answerFour
	 */

	public void setAnswerFour(String answerFour) {
		this.answerFour = answerFour;
	}

	/**
	 * @return answerFive
	 */

	public String getAnswerFive() {
		return answerFive;
	}

	/**
	 * @param answerFive
	 */

	public void setAnswerFive(String answerFive) {
		this.answerFive = answerFive;
	}

	/**
	 * @return answerSix
	 */
	public String getAnswerSix() {
		return answerSix;
	}

	public void setAnswerSix(String answerSix) {
		this.answerSix = answerSix;
	}

	@Override
	public String toString() {
		return "ResultBean [survey=" + survey + ", answerOne=" + answerOne + ", answerTwo=" + answerTwo
				+ ", answerThree=" + answerThree + ", answerFour=" + answerFour + ", answerFive=" + answerFive
				+ ", answerSix=" + answerSix + "]";
	}

	

}