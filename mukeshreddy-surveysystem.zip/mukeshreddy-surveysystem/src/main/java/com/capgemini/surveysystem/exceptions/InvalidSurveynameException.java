package com.capgemini.surveysystem.exceptions;

/**
 * @param String message is the argument for InvliadSurveynameException
 * @exception InvalidSurveynameException it is custom exceptions it extends
 *                                       RunetimeException
 * @throws message survey is not distrubuted
 */

public class InvalidSurveynameException extends RuntimeException {
	private static final long serialVersionUID = 7498537336859391440L;
	String message = "survey is not distrubuted";

	public InvalidSurveynameException() {

	}

	public InvalidSurveynameException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
