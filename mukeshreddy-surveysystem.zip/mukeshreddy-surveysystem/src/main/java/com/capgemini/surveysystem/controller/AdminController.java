package com.capgemini.surveysystem.controller;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveysystem.exceptions.UsernameFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.service.AdminService;

/**
 * Online survey management system project
 * 
 * @author Mukesh Reddy
 */

public class AdminController {

	static final Logger log = Logger.getLogger(AdminController.class);
	static AdminService adminService = Factory.getAdminServiceInstance();
	static Scanner sc = new Scanner(System.in);

	/**
	 * This method is for adminLogin
	 */
	public static void adminLogin() {
		Properties props = new Properties();
		try {
			props.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		String UserName = props.getProperty("adminUsername");
		String Password = props.getProperty("adminPassword");

		boolean login = adminService.loginAdmin(UserName, Password);
		if (login) {
			log.info(" Admin login successfull");
			log.info("*********************************************************");
			adminService();
		} else {
			log.info("Admin login failed");
		}
	}

	/**
	 * Operations after adminLogin
	 */
	public static void adminService() {
		m: do {
			log.info("select a option");
			log.info("1.surveyor login");
			log.info("2.Respondent login");
			log.info("3.Add Respondent");
			log.info("4.Exit");
			log.info("select a choice (1-4))");
			String choice = sc.nextLine();
			while (!adminService.choiceVerify(choice)) {
				log.info("please enter valid choice");
				choice = sc.nextLine();
			}
			int choice1 = Integer.parseInt(choice);

			switch (choice1) {

			case 1:
				SurveyorController.surveyDetails();
				break;
			case 2:
				RespondentController.respondentLogin();

				break;
			case 3:
				log.info("enter respondent username(a-z Ex: mukesh)");
				String userName = sc.nextLine();
				while (!adminService.usernameVerify(userName)) {
					log.info("please enter valid username ");
					userName = sc.nextLine();
				}
				log.info("enter your Mobile Number which starts with (6,7,8,9) and include 10 digits");
				String phoneNo = sc.nextLine();
				while (!adminService.mobileNoVerify(phoneNo)) {
					log.info("please enter valid Mobile No");
					phoneNo = sc.nextLine();
				}
				Long mobileNo = Long.parseLong(phoneNo);

				log.info("enter your password (a to z A to Z 0 to 9 @!#$% )");
				String password = sc.nextLine();
				while (!adminService.passwordVerify(password)) {
					log.info("please enter valid password");
					password = sc.nextLine();
				}
				try {
					boolean isRegistered = adminService.respondentRegistration(userName, mobileNo, password);
					if (isRegistered) {
						log.info("Registered Successfully");
					} else {
						log.info("not Registered");
					}
				} catch (UsernameFoundException e) {
					log.info("Username is already exist. You can Login in Respondent Login");
					break;
				}

				break;
			case 4:
				break m;
			default:
				log.info("Select valid choice");
				break;
			}
		} while (true);

	}

}
