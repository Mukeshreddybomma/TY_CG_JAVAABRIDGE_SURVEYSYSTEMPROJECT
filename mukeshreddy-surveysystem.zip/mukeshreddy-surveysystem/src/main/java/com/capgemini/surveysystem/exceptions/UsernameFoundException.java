package com.capgemini.surveysystem.exceptions;

public class UsernameFoundException extends RuntimeException {

	private static final long serialVersionUID = 1694599778917531958L;

	public UsernameFoundException() {

	}

}
