package com.capgemini.surveysystem.service;

public interface RespondentService {

	public boolean choiceVerify(String choice);

	public boolean usernameVerify(String username);

	public boolean passwordVerify(String password);

	public boolean surveyVerify(String survey);

	public boolean multipleanswerVerify(String answer);

	public boolean phoneNoVerify(String phonenum);

	public boolean answerVerify(String answer);

	public boolean answerVerify1(String answer);

	public boolean addAnswers(String survey, String answerOne, String answerTwo, String answerThree, String answerFour,
			String answerFive, String answerSix);

	public boolean viewResponse();
}
