package com.capgemini.surveysystem.dao;

public interface AdminDAO {
	/**
	 * 
	 * @param Adminusername argument for method adminLogin
	 * @param Adminpassword argument for method AdminLogin
	 */
	public boolean adminLogin(String adminUsername, String adminPassword);

	public boolean respondentRegistration(String userName, Long mobileNo, String password);

}
