package com.capgemini.surveysystem.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveysystem.beans.SurveyBean;
import com.capgemini.surveysystem.factory.Factory;

public class SurveyRepository {
	public static List<SurveyBean> surveylist = new ArrayList<SurveyBean>();

	/**
	 * This method is for dummy data of survey
	 * 
	 * @return true surveyadded
	 */
	public List<SurveyBean> survey() {
		SurveyBean surveybean1 = Factory.getSurveybeanInstance();
		surveybean1.setSurveyName("india");
		surveybean1.setDescription("place");
		surveybean1.setStartDate(LocalDate.of(2015, 11, 16));
		surveybean1.setEndDate(LocalDate.of(2018, 11, 16));
		surveybean1.setQuestionOne("what is your favourite place in india?");
		surveybean1.setQuestionTwo("what is your favourite food in india?");
		surveybean1.setQuestionThree("describe favourite place?");
		surveybean1.setQuestionFour("describe about india?");
		surveybean1.setQuestionFive("which place you like");
		surveybean1.setOptionOne("hyderabad");
		surveybean1.setOptionTwo("mumbai");
		surveybean1.setOptionThree("kerala");
		surveybean1.setOptionFour("goa");
		surveybean1.setQuestionSix("better place to eat");
		surveybean1.setOptionFive("hyderabad");
		surveybean1.setOptionSix("mumbai");
		surveybean1.setOptionSeven("kerala");
		surveybean1.setOptionEight("goa");
		surveybean1.setDistribute("mukeshreddy");
		surveylist.add(surveybean1);

		SurveyBean surveybean2 = Factory.getSurveybeanInstance();
		surveybean2.setSurveyName("amazon");
		surveybean2.setDescription("app");
		surveybean2.setStartDate(LocalDate.of(2015, 11, 16));
		surveybean2.setEndDate(LocalDate.of(2018, 11, 16));
		surveybean2.setQuestionOne("describe about amazon ?");
		surveybean2.setQuestionTwo("product which u like in amazon?");
		surveybean2.setQuestionFour("describe about amazon?");
		surveybean2.setQuestionFour("product which u like in amazon?");
		surveybean2.setQuestionFive("rating for app");
		surveybean2.setOptionOne("good");
		surveybean2.setOptionTwo("bad");
		surveybean2.setOptionThree("excellent");
		surveybean2.setOptionFour("avg");
		surveybean2.setQuestionSix("services provided by amazon");
		surveybean2.setOptionFive("good");
		surveybean2.setOptionSix("excellent");
		surveybean2.setOptionSeven("avg");
		surveybean2.setOptionEight("bad");
		surveybean2.setDistribute("mukeshbomma");
		surveylist.add(surveybean2);

		return surveylist;

	}
}
