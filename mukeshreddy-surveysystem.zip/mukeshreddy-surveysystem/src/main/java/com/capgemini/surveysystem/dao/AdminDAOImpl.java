package com.capgemini.surveysystem.dao;

import java.util.ArrayList;

import com.capgemini.surveysystem.beans.RespondentBean;
import com.capgemini.surveysystem.exceptions.UsernameFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.service.AdminService;

public class AdminDAOImpl implements AdminDAO {
	static AdminService adminserive = Factory.getAdminServiceInstance();
	RespondentBean respondentbean = Factory.getRespondentbeanInstance();

	/**
	 * This methods for adminLogin
	 * 
	 * @param username is the first parameter to adminLogin
	 * @param password is the second parameter to adminLogin
	 * @return true login found
	 * @return false login failed
	 */
	@Override
	public boolean adminLogin(String UserName, String Password) {
		return UserName.contentEquals("mukeshreddy") && Password.equals("Mukesh@13") == true;
	}

	@Override
	public boolean respondentRegistration(String userName, Long mobileNo, String password) {
		boolean useridfound = adminserive.userCheck(userName);
		if (useridfound == false) {
			respondentbean.setUserName(userName);
			respondentbean.setPhoneNo(mobileNo);
			respondentbean.setPassword(password);
			ArrayList<RespondentBean> list = new ArrayList<RespondentBean>();
			list.add(respondentbean);
			RespondentRepository.respondentlist.addAll(list);
			return true;
		} else {
			throw new UsernameFoundException();
		}

	}
}