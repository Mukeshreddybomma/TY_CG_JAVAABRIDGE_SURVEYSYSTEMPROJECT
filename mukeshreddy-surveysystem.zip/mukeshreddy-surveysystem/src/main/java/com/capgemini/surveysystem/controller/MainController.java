package com.capgemini.surveysystem.controller;

import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.service.SurveyorService;
import com.capgemini.surveysystem.validation.InputValidations;

/**
 * This class consists of Main method
 * 
 * @author mukesh reddy
 */
public class MainController {
	static final Logger log = Logger.getLogger(MainController.class);
	static InputValidations inputValidations = Factory.getInputValidationInstance();
	static Scanner sc = new Scanner(System.in);
	/**
	 * main method for login Admin,Surveyor,Respondent
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		SurveyRepository surveyrepository = Factory.getSurveyRepository();
		RespondentRepository respondentRepository = Factory.getRespondentRepository();
		SurveyorService surveyorService = Factory.getSurveyorServiceInstance();
		surveyrepository.survey();
		respondentRepository.respondent();
		log.info("welcome to survey management system");
		do {
			log.info("please tell who are you");
			log.info("1.Admin login");
			log.info("2.Surveyor login");
			log.info("3.Respondent login");
			log.info("4.Exit");
			log.info("select a choice (1-4) ex:1");
			String choice = sc.nextLine();
			while (!surveyorService.choiceVerify(choice)) {
				log.info("please enter valid choice");
				choice = sc.nextLine();
			}
			int choice1 = Integer.parseInt(choice);

			switch (choice1) {
			case 1:
				AdminController.adminLogin();
				break;
			case 2:
				SurveyorController.surveyorLogin();
				break;
			case 3:
				RespondentController.respondentLogin();
				break;
			case 4:
				log.info("Thank you!!");
				sc.close();
				System.exit(0);
				break ;
			default:
				log.info("Select valid choice");
				break;
			}
		} while (true);
	}
}
