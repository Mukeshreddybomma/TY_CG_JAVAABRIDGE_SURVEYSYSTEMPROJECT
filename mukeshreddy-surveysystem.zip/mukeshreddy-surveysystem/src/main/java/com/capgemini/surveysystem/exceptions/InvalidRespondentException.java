package com.capgemini.surveysystem.exceptions;

/**
 * @param message is the argument for InvalidRespondentException
 * @exception InvalidRespondentException it is custom exceptions
 * @throws message Respondent not found
 */
public class InvalidRespondentException extends RuntimeException {
	private static final long serialVersionUID = -1302354225779795804L;
	String message = "Respondent  not found";

	public InvalidRespondentException() {

	}

	public InvalidRespondentException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
