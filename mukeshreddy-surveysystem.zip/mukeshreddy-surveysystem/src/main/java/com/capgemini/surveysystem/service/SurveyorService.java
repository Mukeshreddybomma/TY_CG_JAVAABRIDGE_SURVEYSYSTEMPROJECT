package com.capgemini.surveysystem.service;

import java.time.LocalDate;

public interface SurveyorService {

	public boolean choiceVerify(String choice);

	public boolean descriptionVerify(String description);

	public boolean questionVerify(String question);

	public boolean surveyVerify(String survey);

	public boolean dateVerify(String date);

	public boolean nameVerify(String name);

	public boolean checkSurvey(String newsurvey);

	public boolean optionVerify(String option);

	public boolean updateSurvey(String survey);

	public boolean createSurvey(String survey, String description, LocalDate sd, LocalDate ed, String questionOne,
			String questionTwo, String questionThree, String questionFour, String questionFive, String optionOne, String optionTwo,
			String optionThree, String optionFour, String questionSix, String optionFive, String optionSix, String optionSeven,
			String optionEight, String distribute);

	public boolean loginSurveyor(String UserName, String Password);

	public boolean surveyView();

	public boolean surveyCheck(String surveyName);

	public boolean surveyUpdate(String survey1,String survey2, String description1, LocalDate sd1, LocalDate ed1, String question1,
			String question2, String question3, String question4);

}
