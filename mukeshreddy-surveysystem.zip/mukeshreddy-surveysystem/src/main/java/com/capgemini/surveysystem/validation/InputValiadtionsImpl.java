package com.capgemini.surveysystem.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValiadtionsImpl implements InputValidations {
	Pattern pat = null;
	Matcher mat = null;

	/**
	 * Method is for name validation
	 * 
	 * @param name
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean nameValidation(String name) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(name);
		return mat.matches();
	}

	/**
	 * Method is for date validation
	 * 
	 * @param date
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean dateValidation(String date) {
		pat = Pattern.compile("[0-9]{4}-(0[1-9]|1[0-2])-(3[0-1]|[1-2][0-9]|0[0-9])");
		mat = pat.matcher(date);
		return mat.matches();
	}

	/**
	 * Method is for choice validation
	 * 
	 * @param choice
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean choiceValidation(String choice) {
		pat = Pattern.compile("[1-9&&[^a-zA-Z]]{1}");
		mat = pat.matcher(choice);
		return mat.matches();
	}

	/**
	 * Method is for email validation
	 * 
	 * @param email
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean emailValidation(String email) {
		pat = Pattern.compile("^(.+)@(.+)$");
		mat = pat.matcher(email);
		return mat.matches();
	}

	/**
	 * Method is for password validation
	 * 
	 * @param passcode
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean passwordValidation(String passcode) {
		pat = Pattern.compile("[a-zA-Z0-9@!#$%^&*]+");
		mat = pat.matcher(passcode);
		return mat.matches();
	}

	/**
	 * Method is for mobileNo validation
	 * 
	 * @param phoneNo
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean mobileNoValidation(String phoneNo) {
		pat = Pattern.compile("[6-9][0-9]{9}");
		mat = pat.matcher(phoneNo);
		return mat.matches();
	}

	/**
	 * Method is for survey validation
	 * 
	 * @param survey
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean surveyValidation(String survey) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(survey);
		return mat.matches();
	}

	/**
	 * Method is for description validation
	 * 
	 * @param description
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean descriptionValidation(String description) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*");
		mat = pat.matcher(description);
		return mat.matches();
	}

	/**
	 * Method is for answer validation
	 * 
	 * @param answer
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean answerValidation(String answer) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*{1,250}");
		mat = pat.matcher(answer);
		return mat.matches();
	}

	/**
	 * Method is for multipleanswer validation
	 * 
	 * @param answer
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean multipleanswerValidation(String answer) {
		pat = Pattern.compile("[a-d]{1}");
		mat = pat.matcher(answer);
		return mat.matches();
	}

	/**
	 * Method is for answer1 validation
	 * 
	 * @param answer
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean answerValidation1(String answer) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*{1,4000}");
		mat = pat.matcher(answer);
		return mat.matches();
	}

	/**
	 * Method is for question validation
	 * 
	 * @param question
	 * @return true when matches
	 * @return false when not matches
	 */
	public boolean questionValidation(String question) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*");
		mat = pat.matcher(question);
		return mat.matches();
	}

	/**
	 * Method is for option validation
	 * 
	 * @param option
	 * @return true when matches
	 * @return false when not matches
	 */
	@Override
	public boolean optionValidation(String option) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(option);
		return mat.matches();
	}

}