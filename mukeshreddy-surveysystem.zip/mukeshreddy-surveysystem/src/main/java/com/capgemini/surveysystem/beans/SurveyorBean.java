package com.capgemini.surveysystem.beans;

import java.io.Serializable;

/**
 * This class consists of properties of surveyor Setter and Getter methods of
 * properties
 */
public class SurveyorBean implements Serializable {

	private static final long serialVersionUID = 3043287427110653511L;
	private String userName;
	private String password;
	private Long phoneNo;

	public SurveyorBean() {

	}

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param userName
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return phoneNo
	 */
	public Long getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo
	 */
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "SurveyorBean [userName=" + userName + ", password=" + password + ", phoneNo=" + phoneNo + "]";
	}

}