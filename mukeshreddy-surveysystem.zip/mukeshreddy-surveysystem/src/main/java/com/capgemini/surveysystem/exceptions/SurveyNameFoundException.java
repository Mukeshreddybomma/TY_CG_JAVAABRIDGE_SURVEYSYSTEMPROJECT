package com.capgemini.surveysystem.exceptions;

public class SurveyNameFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1137213531360851883L;

	public SurveyNameFoundException() {
		
	}

}
