package com.capgemini.surveysystem.factory;

import com.capgemini.surveysystem.beans.AdminBean;
import com.capgemini.surveysystem.beans.RespondentBean;
import com.capgemini.surveysystem.beans.ResultBean;
import com.capgemini.surveysystem.beans.SurveyBean;
import com.capgemini.surveysystem.beans.SurveyorBean;
import com.capgemini.surveysystem.dao.AdminDAO;
import com.capgemini.surveysystem.dao.AdminDAOImpl;
import com.capgemini.surveysystem.dao.RespondentDAO;
import com.capgemini.surveysystem.dao.RespondentDAOImpl;
import com.capgemini.surveysystem.dao.SurveyorDAO;
import com.capgemini.surveysystem.dao.SurveyorDAOImpl;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.service.AdminService;
import com.capgemini.surveysystem.service.AdminServiceImpl;
import com.capgemini.surveysystem.service.SurveyorService;
import com.capgemini.surveysystem.service.RespondentService;
import com.capgemini.surveysystem.service.RespondentServiceImpl;
import com.capgemini.surveysystem.service.SurveryorServiceImpl;
import com.capgemini.surveysystem.validation.InputValiadtionsImpl;
import com.capgemini.surveysystem.validation.InputValidations;

/**
 * @author mukesh reddy This class is used for creating objects for all the
 *         classes creating By this we can call the class by using object
 */

public class Factory {
	/**
	 * @return SurveyorBean
	 */
	public static SurveyorBean getSurveyorbeanInstance() {
		return new SurveyorBean();
	}
	/**
	 * @return SurveyorDAOImpl
	 */
	public static SurveyorDAO getSurveyorDAOInstance() {
		return new SurveyorDAOImpl();

	}

	/**
	 * @return SurveyorServiceImpl
	 */
	public static SurveyorService getSurveyorServiceInstance() {
		return new SurveryorServiceImpl();
	}

	/**
	 * @return AdminBean
	 */
	public static AdminBean getAdminbeanInstance() {
		return new AdminBean();

	}

	/**
	 * @return AdminDAOImpl
	 */
	public static AdminDAO getAdminDAOInstance() {
		return new AdminDAOImpl();
	}

	/**
	 * @return AdminServiceImpl
	 */
	public static AdminService getAdminServiceInstance() {
		return new AdminServiceImpl();
	}

	/**
	 * @return RespondentBean
	 */
	public static RespondentBean getRespondentbeanInstance() {
		return new RespondentBean();
	}

	/**
	 * @return RespondentDAOImpl
	 */

	public static RespondentDAO getRespondentDAOInstance() {
		return new RespondentDAOImpl();
	}

	/**
	 * @return RespondentServiceImpl
	 */
	public static RespondentService getRespondentServiceInstance() {
		return new RespondentServiceImpl();
	}

	/**
	 * @return SurveyBean
	 */
	public static SurveyBean getSurveybeanInstance() {
		return new SurveyBean();
	}

	/**
	 * @return ResultBean
	 */
	public static ResultBean getResultbeanInstance() {
		return new ResultBean();

	}

	/**
	 * @return InputValidationsmpl
	 */
	public static InputValidations getInputValidationInstance() {
		return new InputValiadtionsImpl();
	}

	/**
	 * @return SurveyRepository
	 */
	public static SurveyRepository getSurveyRepository() {
		return new SurveyRepository();

	}

	/**
	 * @return RespondentRepository
	 */
	public static RespondentRepository getRespondentRepository() {
		return new RespondentRepository();

	}

}
