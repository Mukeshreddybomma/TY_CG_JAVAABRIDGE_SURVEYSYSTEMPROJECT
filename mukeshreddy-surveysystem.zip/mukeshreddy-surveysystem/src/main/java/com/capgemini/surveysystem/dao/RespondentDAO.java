package com.capgemini.surveysystem.dao;

;

public interface RespondentDAO {
	/**
	 * responseview 
	 */

	public boolean responseView();

	public boolean addAnswers(String survey, String answerOne, String answerTwo, String answerThree, String answerFour,
			String answerFive, String answerSix);

}