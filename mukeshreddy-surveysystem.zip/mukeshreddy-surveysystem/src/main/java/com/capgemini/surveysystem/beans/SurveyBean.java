package com.capgemini.surveysystem.beans;

import java.io.Serializable;

import java.time.LocalDate;

/**
 * 
 * This class consists of properties of survey Setter and Getter methods of
 * properties
 */

public class SurveyBean implements Serializable {

	private static final long serialVersionUID = -7815953991764928593L;
	private String surveyName;
	private String description;
	private LocalDate startDate;
	private LocalDate endDate;
	private String questionOne;
	private String questionTwo;
	private String questionThree;
	private String questionFour;
	private String questionFive;
	private String optionOne;
	private String optionTwo;
	private String optionThree;
	private String optionFour;
	private String questionSix;
	private String optionFive;
	private String optionSix;
	private String optionSeven;
	private String optionEight;

	private String distribute;

	public SurveyBean() {

	}

	public String getSurveyName() {
		return surveyName;
	}

	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getQuestionOne() {
		return questionOne;
	}

	public void setQuestionOne(String questionOne) {
		this.questionOne = questionOne;
	}

	public String getQuestionTwo() {
		return questionTwo;
	}

	public void setQuestionTwo(String questionTwo) {
		this.questionTwo = questionTwo;
	}

	public String getQuestionThree() {
		return questionThree;
	}

	public void setQuestionThree(String questionThree) {
		this.questionThree = questionThree;
	}

	public String getQuestionFour() {
		return questionFour;
	}

	public void setQuestionFour(String questionFour) {
		this.questionFour = questionFour;
	}

	public String getQuestionFive() {
		return questionFive;
	}

	public void setQuestionFive(String questionFive) {
		this.questionFive = questionFive;
	}

	public String getOptionOne() {
		return optionOne;
	}

	public void setOptionOne(String optionOne) {
		this.optionOne = optionOne;
	}

	public String getOptionTwo() {
		return optionTwo;
	}

	public void setOptionTwo(String optionTwo) {
		this.optionTwo = optionTwo;
	}

	public String getOptionThree() {
		return optionThree;
	}

	public void setOptionThree(String optionThree) {
		this.optionThree = optionThree;
	}

	public String getOptionFour() {
		return optionFour;
	}

	public void setOptionFour(String optionFour) {
		this.optionFour = optionFour;
	}

	public String getQuestionSix() {
		return questionSix;
	}

	public void setQuestionSix(String questionSix) {
		this.questionSix = questionSix;
	}

	public String getOptionFive() {
		return optionFive;
	}

	public void setOptionFive(String optionFive) {
		this.optionFive = optionFive;
	}

	public String getOptionSix() {
		return optionSix;
	}

	public void setOptionSix(String optionSix) {
		this.optionSix = optionSix;
	}

	public String getOptionSeven() {
		return optionSeven;
	}

	public void setOptionSeven(String optionSeven) {
		this.optionSeven = optionSeven;
	}

	public String getOptionEight() {
		return optionEight;
	}

	public void setOptionEight(String optionEight) {
		this.optionEight = optionEight;
	}

	public String getDistribute() {
		return distribute;
	}

	public void setDistribute(String distribute) {
		this.distribute = distribute;
	}

	@Override
	public String toString() {
		return "SurveyBean [surveyName=" + surveyName + ", description=" + description + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", questionOne=" + questionOne + ", questionTwo=" + questionTwo
				+ ", questionThree=" + questionThree + ", questionFour=" + questionFour + ", questionFive="
				+ questionFive + ", optionOne=" + optionOne + ", optionTwo=" + optionTwo + ", optionThree="
				+ optionThree + ", optionFour=" + optionFour + ", questionSix=" + questionSix + ", optionFive="
				+ optionFive + ", optionSix=" + optionSix + ", optionSeven=" + optionSeven + ", optionEight="
				+ optionEight + ", distribute=" + distribute + "]";
	}

}