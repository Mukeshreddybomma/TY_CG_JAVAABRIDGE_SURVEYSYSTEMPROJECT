package com.capgemini.surveysystem.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;

class RespondentServiceImplTest {
	RespondentService respondentService = Factory.getRespondentServiceInstance();

	@Test
	void testUsernameVerify() {
		assertEquals(true, respondentService.usernameVerify("mukesh"));
	}

	@Test
	void testPasswordVerify() {
		assertEquals(true, respondentService.passwordVerify("Muk@213"));
	}

	@Test
	void testSurveyVerify() {
		assertEquals(true, respondentService.surveyVerify("mukesh"));
	}

	@Test
	void testMultipleanswerVerify() {
		assertEquals(true, respondentService.multipleanswerVerify("a"));
	}

	@Test
	void testAnswerVerify() {
		assertEquals(true, respondentService.answerVerify("Mukesh reddy "));
	}

	@Test
	void testAnswerVerify1() {
		assertEquals(true, respondentService.answerVerify1("Mukesh reddy bomma"));
	}

	@Test
	void testPhoneNoVerify() {
		assertEquals(true, respondentService.phoneNoVerify("9090922929"));
	}

	@Test
	void testChoiceVerify() {
		assertEquals(true, respondentService.choiceVerify("4"));

	}

	@Test
	void testAddanswers() {
		assertEquals(true,
				respondentService.addAnswers("amazon", " mukesh reddy bomma", " mukesh", "hi", "bye", "a", "b"));
	}

	@Test
	void testViewresponse() {
		assertNotNull(respondentService.viewResponse());

	}

}
