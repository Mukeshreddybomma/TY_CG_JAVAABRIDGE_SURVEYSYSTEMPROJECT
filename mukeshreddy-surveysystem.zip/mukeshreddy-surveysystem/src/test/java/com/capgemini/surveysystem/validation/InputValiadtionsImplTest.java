package com.capgemini.surveysystem.validation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;

class InputValiadtionsImplTest {
	InputValidations inputValidations = Factory.getInputValidationInstance();

	@Test
	void testNameValidation() {
		assertEquals(true, inputValidations.nameValidation("mukesh"));
	}

	@Test
	void testDateValidation() {
		assertEquals(true, inputValidations.dateValidation("2020-01-03"));
	}

	@Test
	void testChoiceValidate() {
		assertEquals(true, inputValidations.choiceValidation("2"));
	}

	@Test
	void testEmailValidation() {
		assertEquals(true, inputValidations.emailValidation("mukeshreddy@gmail.com"));
	}

	@Test
	void testPasswordValidation() {
		assertEquals(true, inputValidations.passwordValidation("Mukesh8@"));
	}

	@Test
	void testMobileNoValidation() {
		assertEquals(true, inputValidations.mobileNoValidation("8096741045"));
	}

	@Test
	void testSurveyValidation() {
		assertEquals(true, inputValidations.surveyValidation("mukesh"));
	}

	@Test
	void testDescriptionValidation() {
		assertEquals(true, inputValidations.descriptionValidation("mukesh"));
	}

	@Test
	void testMultipleanswerValidation() {
		assertEquals(true, inputValidations.multipleanswerValidation("a"));
	}

	@Test
	void testOptionValidation() {
		assertEquals(true, inputValidations.optionValidation("good"));
	}

}
