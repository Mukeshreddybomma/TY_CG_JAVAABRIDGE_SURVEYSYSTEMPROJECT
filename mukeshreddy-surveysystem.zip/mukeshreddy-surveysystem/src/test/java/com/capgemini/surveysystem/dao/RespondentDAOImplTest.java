package com.capgemini.surveysystem.dao;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.RespondentRepository;

class RespondentDAOImplTest {
	RespondentDAO respondentDao = Factory.getRespondentDAOInstance();

	void data() {
		RespondentRepository respondentRepository = Factory.getRespondentRepository();
		respondentRepository.respondent();
	}
	@Test
	void testResponseview() {
		assertNotNull(respondentDao.responseView());
	}
	@Test
	void testAddanswers() {
		assertEquals(true,respondentDao.addAnswers("amazon","good","excellent","average","bad","a","b"));
		
		
	}

}
