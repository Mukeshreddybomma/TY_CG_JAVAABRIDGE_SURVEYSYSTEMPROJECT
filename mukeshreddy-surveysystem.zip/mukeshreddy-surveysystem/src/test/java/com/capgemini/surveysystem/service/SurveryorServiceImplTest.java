package com.capgemini.surveysystem.service;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;

class SurveryorServiceImplTest {
	SurveyorService surveyorService = Factory.getSurveyorServiceInstance();

	@Test
	void testChoiceVerify() {
		assertEquals(true, surveyorService.choiceVerify("5"));

	}

	@Test
	void testDescriptionVerify() {
		assertEquals(true, surveyorService.descriptionVerify("mobile"));
	}

	@Test
	void testQuestionVerify() {
		assertEquals(true, surveyorService.questionVerify("what is your name"));
	}

	@Test
	void testDateVerify() {
		assertEquals(true, surveyorService.dateVerify("2020-10-09"));
	}

	@Test
	void testNameVerify() {
		assertEquals(true, surveyorService.nameVerify("amazon"));

	}

	@Test
	void testOptionVerify() {
		assertEquals(true, surveyorService.optionVerify("good"));

	}

}
