package com.capgemini.surveysystem.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;

class SurveyorDAOImplTest {
	SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();

	@Test
	void testLogin() {
		assertEquals(true, surveyorDao.surveyorLogin("mukeshreddy", "Mukesh@13"));
	}

	@Test
	void testUpdatesurvey() {
		SurveyRepository surveyRepository = Factory.getSurveyRepository();
		surveyRepository.survey();
		assertEquals(true, surveyorDao.updateSurvey("amazon"));

	}

	@Test
	void testDeletesurvey() {
		SurveyRepository surveyRepository = Factory.getSurveyRepository();
		surveyRepository.survey();
		assertEquals(true, surveyorDao.deleteSurvey("india"));

	}

	@Test
	void testViewsurvey() {
		SurveyRepository surveyRepository = Factory.getSurveyRepository();
		surveyRepository.survey();
		assertNotNull(surveyorDao.viewSurvey());

	}
	

}
