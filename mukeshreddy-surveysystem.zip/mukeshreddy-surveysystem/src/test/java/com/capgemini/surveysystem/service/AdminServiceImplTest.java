package com.capgemini.surveysystem.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;

class AdminServiceImplTest {
	AdminService adminService = Factory.getAdminServiceInstance();

	@Test
	void testChoiceVerify() {
		assertEquals(true, adminService.choiceVerify("4"));
	}
	@Test
	void testUsernameVerify() {
		assertEquals(true, adminService.usernameVerify("mukesh"));
	}

	@Test
	void testPasswordVerify() {
		assertEquals(true, adminService.passwordVerify("Muk@213"));
	}
	@Test
	void testPhoneNoVerify() {
		assertEquals(true, adminService.mobileNoVerify("9090922929"));
	}
}
