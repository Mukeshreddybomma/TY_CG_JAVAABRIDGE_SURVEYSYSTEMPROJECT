package com.capgemini.surveysystem.dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;

class AdminDAOImplTest {
	AdminDAO adminDao = Factory.getAdminDAOInstance();

	@Test
	void testAdminlogin() {
		assertEquals(true, adminDao.adminLogin("mukeshreddy", "Mukesh@13"));
	}
	@Test
	void testRespondentregistration() {
		assertEquals(true,adminDao.respondentRegistration("mukeshreddy", 8080808080l, "mukesK@13"));
	}
	
	

}
